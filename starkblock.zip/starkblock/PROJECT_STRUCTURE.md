# 📁 Project Structure

This document explains the organization of the StarkBlock codebase.

```
starkblock/
│
├── 📄 manifest.json              # Extension configuration (Manifest V3)
│
├── 📄 popup.html                 # Main popup interface HTML
│
├── 📂 js/                        # JavaScript files
│   ├── popup.js                  # Popup UI logic and interactions
│   ├── background.js             # Background service worker
│   └── content.js                # Content scripts (runs on web pages)
│
├── 📂 css/                       # Stylesheets
│   ├── popup.css                 # Popup interface styles
│   └── content.css               # Styles injected into web pages
│
├── 📂 filters/                   # Blocking rules
│   └── rules.json                # declarativeNetRequest rules
│
├── 📂 icons/                     # Extension icons
│   ├── icon16.png               # Toolbar icon (16x16)
│   ├── icon32.png               # Extension list icon (32x32)
│   ├── icon48.png               # Extension details icon (48x48)
│   ├── icon128.png              # Chrome Web Store icon (128x128)
│   └── icon128.svg              # Source SVG file
│
├── 📂 assets/                    # Additional assets (currently empty)
│
├── 📄 README.md                  # Main documentation
├── 📄 QUICKSTART.md             # Quick setup guide
├── 📄 CONTRIBUTING.md           # Contribution guidelines
├── 📄 CHANGELOG.md              # Version history
├── 📄 LICENSE                   # MIT License
└── 📄 .gitignore                # Git ignore rules
```

## File Details

### Core Extension Files

#### `manifest.json`
**Purpose**: Extension configuration and permissions
- Defines extension metadata (name, version, description)
- Declares required permissions
- Configures content scripts and background workers
- Sets up declarativeNetRequest rules

#### `popup.html`
**Purpose**: Main user interface
- Dashboard layout with arc reactor animation
- Statistics display (blocks, data saved, time saved)
- Protection mode selector
- Quick action buttons
- Threat list display

### JavaScript Files

#### `js/popup.js`
**Purpose**: Popup interface logic
- **Statistics Management**: Load and display blocking stats
- **Settings Control**: Handle protection mode switching
- **Event Handlers**: Button clicks, toggles, mode changes
- **Real-time Updates**: Listen for stat updates from background
- **Whitelist Management**: Add/remove sites from whitelist
- **Element Zapper**: Activate zapper mode
- **Animations**: UI animations and transitions

Key Functions:
- `loadStats()` - Load statistics from storage
- `updateStatsDisplay()` - Refresh UI with current stats
- `startRealTimeUpdates()` - Listen for background updates
- `updateThreatList()` - Display blocked threats
- `showNotification()` - Display toast notifications

#### `js/background.js`
**Purpose**: Core blocking engine (service worker)
- **Request Interception**: Monitor and block web requests
- **Statistics Tracking**: Count blocks, estimate savings
- **Mode Management**: Apply different blocking strategies
- **Whitelist Processing**: Check if sites should be allowed
- **Tab Management**: Track per-tab statistics
- **Message Handling**: Communicate with popup and content scripts

Key Functions:
- `shouldBlock()` - Determine if URL should be blocked
- `getBlockType()` - Categorize blocked content
- `estimateDataSaved()` - Calculate data savings
- `handleElementZap()` - Store zapped element selectors
- `updateBlockingRules()` - Refresh blocking rules

#### `js/content.js`
**Purpose**: Page-level interventions
- **Element Zapper**: Interactive element removal tool
- **Cookie Banners**: Auto-remove consent popups
- **YouTube Blocker**: Specialized YouTube ad removal
- **Annoying Elements**: Remove popups and overlays
- **Zapped Elements**: Apply previously zapped selectors

Key Functions:
- `activateElementZapper()` - Enable click-to-remove mode
- `blockCookieBanners()` - Remove cookie consent banners
- `initYouTubeBlocker()` - Skip YouTube ads
- `generateSelector()` - Create CSS selector for elements
- `hideElement()` - Hide elements by selector

### CSS Files

#### `css/popup.css`
**Purpose**: Popup interface styling
- Tony Stark/Arc Reactor theme
- Custom animations (pulse, rotate, glow)
- Responsive layout
- Dark metallic color scheme
- Custom scrollbars

Key Features:
- CSS variables for theming
- Arc reactor animation
- Mode button states
- Stat card hover effects
- Custom toggle switch

#### `css/content.css`
**Purpose**: Page-level styles
- Hide common ad containers
- Remove cookie banners
- Hide tracking pixels
- YouTube ad container removal
- Subtle StarkBlock watermark

### Filter Files

#### `filters/rules.json`
**Purpose**: Network-level blocking rules
- declarativeNetRequest rule definitions
- Block known ad networks
- Block tracking domains
- Block analytics scripts

Format:
```json
{
  "id": 1,
  "priority": 1,
  "action": { "type": "block" },
  "condition": {
    "urlFilter": "*domain.com*",
    "resourceTypes": ["script", "xmlhttprequest"]
  }
}
```

## Data Flow

### 1. Page Load
```
Web Request → background.js (shouldBlock) → Block/Allow → Update Stats
```

### 2. Popup Interaction
```
User Click → popup.js → chrome.storage → background.js → Update UI
```

### 3. Element Zapper
```
User Click → popup.js → content.js → Activate Zapper → Save Selector → background.js
```

### 4. Statistics Update
```
background.js → chrome.storage → popup.js → Update Display
```

## Chrome APIs Used

- **chrome.runtime**: Messaging between components
- **chrome.storage.local**: Persist settings and stats
- **chrome.webRequest**: Intercept network requests
- **chrome.declarativeNetRequest**: Manifest V3 blocking
- **chrome.tabs**: Tab management and messaging
- **chrome.action**: Badge updates

## Storage Schema

```javascript
{
  stats: {
    blockedCount: number,
    dataSaved: number,
    timeSaved: number,
    speedBoost: number
  },
  settings: {
    enabled: boolean,
    mode: 'stealth' | 'standard' | 'aggressive'
  },
  whitelist: string[],
  zappedElements: {
    [domain]: string[]  // CSS selectors
  },
  tabStats_[tabId]: {
    blocked: Array<{type, url, timestamp}>
  }
}
```

## Performance Considerations

- **Lightweight**: Total size under 2MB
- **Efficient**: Minimal CPU usage with observer patterns
- **Fast**: Network-level blocking for immediate results
- **Smart Caching**: Reuse compiled selectors
- **Debounced Updates**: Prevent excessive storage writes

## Security

- **No External Calls**: All processing is local
- **No Data Collection**: Zero telemetry
- **Sandboxed**: Follows Chrome extension security model
- **CSP Compliant**: Content Security Policy adherence

## Future Enhancements

Planned additions to project structure:
- `options.html` - Full settings page
- `report.html` - Detailed statistics page
- `filters/community.json` - Community-contributed rules
- `js/ml-detector.js` - Machine learning ad detection
- `tests/` - Automated test suite
